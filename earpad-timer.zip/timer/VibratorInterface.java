package timer;

interface VibratorInterface
{
	void vibrate();
}
