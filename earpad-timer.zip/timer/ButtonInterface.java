package timer;

interface ButtonInterface
{
	void onButtonPressed();
}
