package timer;

enum Type
{
	BALL, WHEEL
}